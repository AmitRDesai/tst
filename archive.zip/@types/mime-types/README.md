# Installation
> `npm install --save @types/mime-types`

# Summary
This package contains type definitions for mime-types (https://github.com/jshttp/mime-types#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mime-types

Additional Details
 * Last updated: Tue, 18 Apr 2017 15:04:41 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Gyusun Yeom <https://github.com/Perlmint>.
