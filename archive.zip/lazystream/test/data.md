> Never mind, hey, this is really exciting, so much to find out about, so much to
> look forward to, I'm quite dizzy with anticipation . . . Or is it the wind?
> 
> There really is a lot of that now, isn't there? And wow! Hey! What's this thing
> suddenly coming toward me very fast? Very, very fast. So big and flat and round,
> it needs a big wide-sounding name like . . . ow . . . ound . . . round . . .
> ground! That's it! That's a good name- ground!
>
> I wonder if it will be friends with me?
>
> Hello Ground!

And the rest, after a sudden wet thud, was silence.
